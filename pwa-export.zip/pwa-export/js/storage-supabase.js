/**
 * storage-supabase.js — NOT ACTIVE BY DEFAULT.
 *
 * This is a starting template, written but not tested against a real
 * Supabase project (I don't have your credentials from inside this chat).
 * Give this file + supabase/schema.sql to Claude Code and ask it to wire
 * this in and verify it end-to-end — that's a normal, quick task for it.
 *
 * To activate once it's verified working:
 *   1. In index.html, replace the line
 *        <script src="js/storage-polyfill.js"></script>
 *      with
 *        <script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/dist/umd/supabase.js"></script>
 *        <script src="js/storage-supabase.js"></script>
 *   2. Fill in SUPABASE_URL and SUPABASE_ANON_KEY below (Project Settings → API).
 *   3. Run supabase/schema.sql in the Supabase SQL editor first.
 *
 * Everything else in app.js is unchanged — it only ever calls
 * window.storage.get/set/delete/list, same as with the localStorage version.
 */
(function () {
  const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
  const SUPABASE_ANON_KEY = 'YOUR-ANON-KEY';

  const client = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY);
  let userIdPromise = null;

  async function getUserId() {
    if (userIdPromise) return userIdPromise;
    userIdPromise = (async () => {
      const { data: { session } } = await client.auth.getSession();
      if (session && session.user) return session.user.id;
      // Anonymous sign-in — fine for a single-person app on one's own devices.
      // Requires "Allow anonymous sign-ins" enabled in Supabase Auth settings.
      const { data, error } = await client.auth.signInAnonymously();
      if (error) throw error;
      return data.user.id;
    })();
    return userIdPromise;
  }

  window.storage = {
    async get(key, _shared) {
      const userId = await getUserId();
      const { data, error } = await client
        .from('app_storage')
        .select('value')
        .eq('user_id', userId)
        .eq('key', key)
        .maybeSingle();
      if (error) throw error;
      if (!data) throw new Error('key not found: ' + key);
      return { key, value: data.value, shared: false };
    },
    async set(key, value, _shared) {
      const userId = await getUserId();
      const { error } = await client
        .from('app_storage')
        .upsert({ user_id: userId, key, value }, { onConflict: 'user_id,key' });
      if (error) { console.error(error); return null; }
      return { key, value, shared: false };
    },
    async delete(key, _shared) {
      const userId = await getUserId();
      const { error } = await client
        .from('app_storage')
        .delete()
        .eq('user_id', userId)
        .eq('key', key);
      if (error) { console.error(error); return null; }
      return { key, deleted: true, shared: false };
    },
    async list(prefix, _shared) {
      const userId = await getUserId();
      let query = client.from('app_storage').select('key').eq('user_id', userId);
      if (prefix) query = query.like('key', prefix + '%');
      const { data, error } = await query;
      if (error) throw error;
      return { keys: data.map(r => r.key), prefix: prefix || undefined, shared: false };
    }
  };
})();
