/**
 * api-config.js
 *
 * Inside Claude.ai, calls to api.anthropic.com are proxied automatically —
 * no key needed. Standalone, that proxy doesn't exist, so the app needs
 * the user's own Anthropic API key to keep the photo/text food-analysis
 * feature working.
 *
 * SECURITY NOTE: the key is stored in this browser's localStorage and
 * sent directly from the browser to api.anthropic.com using Anthropic's
 * official "anthropic-dangerous-direct-browser-access" CORS header. That
 * name is intentionally scary — it means the key is visible to anyone who
 * opens this browser's dev tools. Fine for a private app only you use on
 * your own phone. Do NOT deploy this publicly with your key embedded.
 */
(function () {
  const KEY_STORAGE = 'coach_center:anthropic_api_key';

  window.apiConfig = {
    getKey() {
      return localStorage.getItem(KEY_STORAGE) || '';
    },
    setKey(key) {
      localStorage.setItem(KEY_STORAGE, key.trim());
    },
    hasKey() {
      return !!this.getKey();
    },
    headers() {
      return {
        'Content-Type': 'application/json',
        'x-api-key': this.getKey(),
        'anthropic-version': '2023-06-01',
        'anthropic-dangerous-direct-browser-access': 'true'
      };
    }
  };

  // Minimal settings UI: a small floating gear that opens a prompt-based
  // key entry. Kept intentionally simple — swap for a nicer modal if you
  // extend this in Claude Code.
  window.addEventListener('DOMContentLoaded', () => {
    const btn = document.createElement('button');
    btn.textContent = '🔑';
    btn.title = 'Настроить API-ключ Anthropic';
    btn.style.cssText = 'position:fixed;bottom:16px;right:16px;z-index:9999;width:40px;height:40px;border-radius:50%;background:#1e1f23;border:1px solid #34363c;color:#f5f3ee;font-size:16px;cursor:pointer;';
    btn.addEventListener('click', () => {
      const current = window.apiConfig.getKey();
      const val = prompt(
        'Вставь свой Anthropic API-ключ (получить: console.anthropic.com → API Keys).\n' +
        'Нужен только для фото/текст-анализа еды. Хранится только в этом браузере.',
        current
      );
      if (val !== null) window.apiConfig.setKey(val);
    });
    document.body.appendChild(btn);
  });
})();
